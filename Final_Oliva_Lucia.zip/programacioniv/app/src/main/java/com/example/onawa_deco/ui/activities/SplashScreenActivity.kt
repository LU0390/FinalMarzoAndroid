package com.example.onawa_deco.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import com.example.onawa_deco.R

class
SplashScreenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        Handler().postDelayed(
            {
                LaunchMainActivity()
                finish()
            }, 2500
        )
    }

    private fun LaunchMainActivity() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
    }
}