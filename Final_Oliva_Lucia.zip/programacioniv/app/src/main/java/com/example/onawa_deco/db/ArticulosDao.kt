package com.example.onawa_deco.db

import android.content.Context
import com.example.onawa_deco.data.Articulo
import com.j256.ormlite.android.apptools.OpenHelperManager
import com.j256.ormlite.dao.Dao
import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class ArticulosDao(context: Context) {

    private var dao: Dao<Articulo, Int>

    init {
        val helper = OpenHelperManager.getHelper(context, DBHelper::class.java)
        dao = helper.getDao(Articulo::class.java)
    }

    fun addArticulo(articulo: Articulo): Completable {
        return Completable
            .fromCallable { dao.create(articulo) }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
    }

    fun deleteArticulo(articulo: Articulo): Completable {
        return Completable
            .fromCallable { dao.delete(articulo) }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
    }

    fun updateArticulo(articulo: Articulo): Completable {
        return Completable
            .fromCallable { dao.update(articulo) }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
    }

    fun getArticulos(): Single<List<Articulo>> {
        return Single
            .fromCallable { dao.queryForAll() }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
    }

    fun getArticulo(articuloId: Int?): Single<Articulo> {
        return Single
            .fromCallable { dao.queryForId(articuloId) }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())

    }
}