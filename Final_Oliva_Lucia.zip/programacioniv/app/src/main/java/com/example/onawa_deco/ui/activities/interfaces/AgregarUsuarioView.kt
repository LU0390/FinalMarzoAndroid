package com.example.onawa_deco.ui.activities.interfaces

interface AgregarUsuarioView {
    fun showLoading()
    fun hideLoading()
    fun goBack()
    fun showErrorMessage()
    fun showSuccessMessage()
}