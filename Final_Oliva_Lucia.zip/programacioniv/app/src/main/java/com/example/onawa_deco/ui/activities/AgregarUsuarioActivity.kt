package com.example.onawa_deco.ui.activities

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.onawa_deco.R
import com.example.onawa_deco.data.Usuario
import com.example.onawa_deco.db.UsuariosDao
import com.example.onawa_deco.extensions.getTextFrom
import com.example.onawa_deco.extensions.mostrarMensaje
import com.example.onawa_deco.extensions.validarMailValido
import com.example.onawa_deco.model.AgregarUsuarioRepositoryImp
import com.example.onawa_deco.presenter.AgregarUsuarioPresenter
import com.example.onawa_deco.presenter.AgregarUsuarioPresenterImp
import com.example.onawa_deco.ui.activities.interfaces.AgregarUsuarioView
import com.google.android.material.textfield.TextInputEditText
import io.reactivex.SingleObserver
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import kotlinx.android.synthetic.main.activity_agregar_usuario.*
import kotlinx.android.synthetic.main.activity_login.*


class AgregarUsuarioActivity : AppCompatActivity(), AgregarUsuarioView {
    private lateinit var etNombre: TextInputEditText
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPass: TextInputEditText
    private lateinit var btnSave: Button
    private val compositeDisposable = CompositeDisposable()
    private val context = this@AgregarUsuarioActivity
    private val presenter: AgregarUsuarioPresenter by lazy {
        AgregarUsuarioPresenterImp(
            this,
            AgregarUsuarioRepositoryImp(
                UsuariosDao(context.applicationContext),
                compositeDisposable
            )
        )
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_agregar_usuario)
        setupUI()
    }

    private fun setupUI() {
        etNombre = findViewById(R.id.etNombreUsuario)
        etEmail = findViewById(R.id.etEmail)
        etPass = findViewById(R.id.etPass)
        btnSave = findViewById(R.id.btnGuardarUsuario)
        btnSave.setOnClickListener { guardar() }
    }

    private fun guardar() {
        val mail = getTextFrom(etEmail)
        val contaseña = getTextFrom(etPass)
        validarExisteUsuario(mail, contaseña)

    }

    private fun guardarUsuarioOk() {
        val usuarioAgregar = createUsuario()
        presenter.doAgregarUsuario(usuarioAgregar)
    }

    private fun validarExisteUsuario(mail: String, pass: String) {
        UsuariosDao(context.applicationContext).getUsuario(mail, pass)
            .subscribe(object : SingleObserver<Usuario> {
                override fun onSubscribe(d: Disposable) {
                    compositeDisposable.add(d)
                }

                override fun onSuccess(usuarios: Usuario) {
                    mostrarMensaje(getString(R.string.ErrorUsuario), context)
                }

                override fun onError(e: Throwable) {
                    validarDatosIngresados()
                }
            })
    }

    private fun validarDatosIngresados() {

        val mail = getTextFrom(etEmail)
        val contaseña = getTextFrom(etPass)
        val nombre = getTextFrom(etNombre)

        if (mail.isNullOrEmpty() || contaseña.isNullOrEmpty() || nombre.isNullOrEmpty()) {
            mostrarMensaje(getString(R.string.ErrorFaltanCompletarDatos), context)
        } else {
            val mailOk = validarMailValido(mail)
            if (mailOk == true) {
                guardarUsuarioOk()
            } else
                mostrarMensaje(getString(R.string.MailError), this)

        }

    }

    private fun createUsuario(): Usuario {
        return Usuario(
            getTextFrom(etNombre),
            getTextFrom(etEmail),
            getTextFrom(etPass)
        )
    }

    override fun showLoading() {
        progressBar.visibility = View.VISIBLE

    }

    override fun hideLoading() {
        progressBar.visibility = View.INVISIBLE
    }

    override fun goBack() {
        finish()
    }

    override fun showErrorMessage() {
        mostrarMensaje(getString(R.string.ErrorAgregarUsuario), context)
    }

    override fun showSuccessMessage() {
        mostrarMensaje(getString(R.string.UsuarioAgregadoCorrecto), context)
    }

    override fun onStop() {
        super.onStop()
        compositeDisposable.clear()
    }
}