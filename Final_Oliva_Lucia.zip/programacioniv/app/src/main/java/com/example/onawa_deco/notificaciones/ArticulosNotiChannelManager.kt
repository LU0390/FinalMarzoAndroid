package com.example.onawa_deco.notificaciones

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationManagerCompat

object ArticulosNotiChannelManager {
    const val NEW_ARTICULOS_CHANNEL_ID = "1"
    private const val NEW_ARTICULOS_CHANNEL_NAME = "Nueva Compra"
    private const val NEW_ARTICULOS_CHANNEL_DESCRIPTION =
        "Tiene una nueva notificacion de Onawa para avisarle que le llegara un mail con los pasos a seguir para finalizar su compra"

    fun createNotiChanelForNotification(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = NotificationManagerCompat.from(context)

            val channel = NotificationChannel(
                NEW_ARTICULOS_CHANNEL_ID,
                NEW_ARTICULOS_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            )
            channel.description = NEW_ARTICULOS_CHANNEL_DESCRIPTION
            notificationManager.createNotificationChannel(channel)
        }
    }

}