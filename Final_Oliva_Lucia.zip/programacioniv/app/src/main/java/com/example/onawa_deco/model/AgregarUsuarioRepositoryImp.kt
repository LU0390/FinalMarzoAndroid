package com.example.onawa_deco.model

import com.example.onawa_deco.db.UsuariosDao
import com.example.onawa_deco.data.Usuario
import io.reactivex.disposables.CompositeDisposable

class AgregarUsuarioRepositoryImp(
    private val usuariosDao: UsuariosDao,
    private val compositeDisposable: CompositeDisposable
) : AgregarUsuarioRepository {


    override fun agregarUsuario(usuario: Usuario, success: () -> Unit, error: () -> Unit) {
        compositeDisposable.add(
            usuariosDao
                .addUsuario(usuario)
                .subscribe(
                    {
                        success()
                    }, {
                        error()
                    }
                )
        )
    }
}