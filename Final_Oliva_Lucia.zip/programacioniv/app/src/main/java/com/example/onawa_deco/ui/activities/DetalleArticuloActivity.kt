package com.example.onawa_deco.ui.activities

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.onawa_deco.R
import com.example.onawa_deco.data.Articulo
import com.example.onawa_deco.db.ArticulosDao
import com.example.onawa_deco.extensions.mostrarMensaje
import io.reactivex.SingleObserver
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable

class DetalleArticuloActivity : AppCompatActivity() {

    private lateinit var imImagen: ImageView
    private lateinit var etName: TextView
    private lateinit var etPrice: TextView
    private lateinit var etDescription: TextView
    private val compositeDisposable = CompositeDisposable()
    private var context = this@DetalleArticuloActivity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle_articulo)
        setupUI()
    }


    private fun setupUI() {
        imImagen = findViewById(R.id.imArticuloModificar)
        etName = findViewById(R.id.tvNombreArtDetalle)
        etPrice = findViewById(R.id.tvPrecioArt)
        etDescription = findViewById(R.id.tvDescripcionArticulo)

        cargarArticulo()
    }

    private fun cargarArticulo() {
        val bundle = intent.extras
        var idArticulo = bundle?.getInt(getString(R.string.Articulo)) ?: 0
        ArticulosDao(context.applicationContext)
            .getArticulo(idArticulo)
            .subscribe(object : SingleObserver<Articulo> {
                override fun onSubscribe(d: Disposable) {
                    compositeDisposable.add(d)
                }

                override fun onError(e: Throwable) {
                    mostrarMensaje(getString(R.string.ErrorCargarUsuarios), context)
                }

                override fun onSuccess(articulo: Articulo) {
                    etName.setText(articulo.name)
                    etPrice.setText(articulo.price)
                    etDescription.setText(articulo.description)
                }
            })

    }

}