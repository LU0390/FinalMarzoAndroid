package com.example.onawa_deco.data

import android.os.Parcelable
import com.j256.ormlite.field.DatabaseField
import com.j256.ormlite.table.DatabaseTable
import kotlinx.android.parcel.Parcelize

@DatabaseTable(tableName = "Articulos")
@Parcelize
class Articulo(
    @DatabaseField(columnName = "ImageResource")
    val resImage: Int,
    @DatabaseField
    var name: String,
    @DatabaseField
    var price: String,
    @DatabaseField
    var description: String,
    @DatabaseField(id = true)
    val id: Int? = null
) : Parcelable {

    constructor() : this(0, "", "", "")

}
