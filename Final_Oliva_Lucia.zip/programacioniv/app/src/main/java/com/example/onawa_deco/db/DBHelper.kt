package com.example.onawa_deco.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.example.onawa_deco.data.Articulo
import com.example.onawa_deco.data.Usuario
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper
import com.j256.ormlite.support.ConnectionSource
import com.j256.ormlite.table.TableUtils

class DBHelper(context: Context) : OrmLiteSqliteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    override fun onCreate(database: SQLiteDatabase?, connectionSource: ConnectionSource?) {
        TableUtils.createTableIfNotExists(connectionSource, Articulo::class.java)
        TableUtils.createTableIfNotExists(connectionSource, Usuario::class.java)
    }

    override fun onUpgrade(
        database: SQLiteDatabase?,
        connectionSource: ConnectionSource?,
        oldVersion: Int,
        newVersion: Int
    ) {
        if (oldVersion == 1 && newVersion == 2) {
            TableUtils.createTableIfNotExists(connectionSource, Usuario::class.java)

        }
        onCreate(database, connectionSource)
    }

}