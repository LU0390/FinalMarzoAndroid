package com.example.onawa_deco.preferences

import android.os.Bundle
import androidx.preference.PreferenceFragmentCompat
import com.example.onawa_deco.R

class PreferencesFragment : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)
    }
}