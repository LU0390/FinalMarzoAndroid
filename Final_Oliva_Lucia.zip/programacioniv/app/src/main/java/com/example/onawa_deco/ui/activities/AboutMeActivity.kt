package com.example.onawa_deco.ui.activities

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageButton
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.example.onawa_deco.R
import com.example.onawa_deco.extensions.createMenu
import com.example.onawa_deco.extensions.mostrarMensaje
import com.example.onawa_deco.preferences.PreferencesActivity
import com.google.android.material.navigation.NavigationView


class AboutMeActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    private var mDrawerLayout: DrawerLayout? = null
    private var mDrawerToggle: ActionBarDrawerToggle? = null
    private var navigationView: NavigationView? = null
    private lateinit var btnRedes: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_me)
        setUpUI()
    }

    private fun setUpUI() {
        val toolbar =
            findViewById<Toolbar>(R.id.toolBar)
        setSupportActionBar(toolbar)
        mDrawerLayout = findViewById(R.id.drawerLayout)
        mDrawerToggle =
            ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.open, R.string.close)
        mDrawerLayout!!.addDrawerListener(mDrawerToggle!!)
        mDrawerToggle!!.syncState()
        navigationView = findViewById(R.id.nav_view)
        navigationView!!.setNavigationItemSelectedListener(this)
        btnRedes = findViewById(R.id.ibIgOnawa)
        btnRedes.setOnClickListener { verRedesOnawa() }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.home -> {
                cargarActivity(MainActivity(), 1)
            }
            R.id.itemAboutMe -> {
                mostrarMensaje(getString(R.string.SeccionOnawa), this)
            }
            R.id.itemAbmArticulos -> {
                cargarActivity(AbmArticulosActivity(), 0)
            }
            R.id.itemUsuarios -> {
                cargarActivity(AbmUsuariosActivity(), 0)
            }
            R.id.contacto -> {
                mostrarMensaje(getString(R.string.TrabajandoEnLaSeccion), this)
            }
        }
        mDrawerLayout!!.closeDrawer(GravityCompat.START)
        return false
    }


    private fun cargarActivity(activity: AppCompatActivity, flagPrincipal: Int) {
        val intent = Intent(this, activity::class.java)
        if (flagPrincipal == 1) {
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
    }

    override fun onBackPressed() {
        if (mDrawerLayout!!.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout!!.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    private fun verRedesOnawa() {
        URL = getString(R.string.PaginaOnawa)
        cargarActivity(PaginasWebActivity(), 0)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return createMenu(menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.itemPreferencias -> cargarActivity(PreferencesActivity(), 0)
            R.id.itemLogOut -> finishAffinity()
        }
        return super.onOptionsItemSelected(item)
    }


}