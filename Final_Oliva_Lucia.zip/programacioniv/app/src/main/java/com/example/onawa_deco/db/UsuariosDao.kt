package com.example.onawa_deco.db

import android.content.Context
import com.example.onawa_deco.data.Usuario
import com.j256.ormlite.android.apptools.OpenHelperManager
import com.j256.ormlite.dao.Dao
import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class UsuariosDao(context: Context) {

    private var dao: Dao<Usuario, Int>

    init {
        val helper = OpenHelperManager.getHelper(context, DBHelper::class.java)
        dao = helper.getDao(Usuario::class.java)
    }

    fun addUsuario(usuario: Usuario): Completable {
        return Completable
            .fromCallable { dao.create(usuario) }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
    }

    fun deleteUsuario(usuario: Usuario): Completable {
        return Completable
            .fromCallable { dao.delete(usuario) }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
    }

    fun getUsuario(): Single<List<Usuario>> {
        return Single
            .fromCallable { dao.queryForAll() }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
    }


    fun getUsuario(mail: String, password: String): Single<Usuario> {
        return Single
            .fromCallable {
                dao.queryForAll().filter { dbUsuario ->
                    dbUsuario.mail == mail &&
                            dbUsuario.contraseña == password
                }.first()
            }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())

    }
}
