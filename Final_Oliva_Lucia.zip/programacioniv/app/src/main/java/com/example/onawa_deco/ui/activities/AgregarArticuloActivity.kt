package com.example.onawa_deco.ui.activities

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.onawa_deco.R
import com.example.onawa_deco.data.Articulo
import com.example.onawa_deco.db.ArticulosDao
import com.example.onawa_deco.extensions.getTextFrom
import com.example.onawa_deco.extensions.mostrarMensaje
import com.google.android.material.textfield.TextInputEditText
import io.reactivex.CompletableObserver
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable


class AgregarArticuloActivity : AppCompatActivity() {
    private lateinit var etName: TextInputEditText
    private lateinit var etPrice: TextInputEditText
    private lateinit var etDescription: TextInputEditText
    private lateinit var btnSave: Button
    private val compositeDisposable = CompositeDisposable()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_agregar_articulo)
        setupUI()
    }

    private fun setupUI() {
        etName = findViewById(R.id.etName)
        etPrice = findViewById(R.id.etPrice)
        etDescription = findViewById(R.id.etDescription)
        btnSave = findViewById(R.id.btnSave)
        btnSave.setOnClickListener { guardarArticulo() }
    }

    private fun guardarArticulo() {
        validateData()
        if (isDataValid()) {
            ArticulosDao(this@AgregarArticuloActivity.applicationContext)
                .addArticulo(createArticuloFromInput())
                .subscribe(object : CompletableObserver {
                    override fun onSubscribe(d: Disposable) {
                        compositeDisposable.add(d)
                    }
                    override fun onComplete() {
                     mostrarMensaje(getString(R.string.ArtAgregado),this@AgregarArticuloActivity)
                        finish()
                    }
                    override fun onError(e: Throwable) {
                        mostrarMensaje(getString(R.string.ErrorArtAgregado),this@AgregarArticuloActivity)
                    }
                })
        }
    }

    private fun isDataValid() =
        etName.error.isNullOrEmpty() && etPrice.error.isNullOrEmpty()

    private fun createArticuloFromInput(): Articulo {
        return Articulo(
            R.drawable.logoonawa,
            getTextFrom(etName),
            getTextFrom(etPrice),
            getTextFrom(etDescription)
        )
    }

    private fun validateData() {
        validateName()
        validatePrice()
    }

    private fun validateName() {
        if (getTextFrom(etName).isEmpty()) {
            getString(R.string.FillName)
        }
    }

    private fun validatePrice() {
        if (getTextFrom(etPrice).isEmpty()) {
            etPrice.error = getString(R.string.FillPrice)
        }
    }


}