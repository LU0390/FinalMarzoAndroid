package com.example.onawa_deco.presenter

import com.example.onawa_deco.data.Usuario
import com.example.onawa_deco.model.AgregarUsuarioRepository
import com.example.onawa_deco.ui.activities.interfaces.AgregarUsuarioView

class AgregarUsuarioPresenterImp(
    private val view: AgregarUsuarioView,
    private val repository: AgregarUsuarioRepository
) : AgregarUsuarioPresenter {
    override fun doAgregarUsuario(usuario: Usuario) {
        view.showLoading()
        repository
            .agregarUsuario(usuario, {
                view.hideLoading()
                view.showSuccessMessage()
                view.goBack()

            }, {
                view.hideLoading()
                view.showErrorMessage()
            })

    }
}