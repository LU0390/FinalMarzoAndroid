package com.example.onawa_deco.data

import com.squareup.moshi.JsonClass


@JsonClass(generateAdapter = true)
class NovedadResponse(
    val id: Int,
    val description: String
)

