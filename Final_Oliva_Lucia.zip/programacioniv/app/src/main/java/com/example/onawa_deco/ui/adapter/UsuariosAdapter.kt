package com.example.onawa_deco.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.onawa_deco.R
import com.example.onawa_deco.data.Usuario


class UsuariosAdapter(val listener: UsuariosListener) :
    RecyclerView.Adapter<UsuariosAdapter.UsuariosViewHolder>() {


    class UsuariosViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imagenUsuario = itemView.findViewById<ImageView>(R.id.imgUsuario)
        val txtName: TextView = itemView.findViewById(R.id.txtNombreUsuario)
        val txtMail: TextView = itemView.findViewById(R.id.txtMail)
        val txtContraseña: TextView = itemView.findViewById(R.id.txtContraseña)
    }

    private var usuarios: List<Usuario> = emptyList()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsuariosViewHolder {
        val itemView = LayoutInflater
            .from(parent.context)
            .inflate(
                R.layout.item_usuario,
                parent,
                false
            )

        return UsuariosViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: UsuariosViewHolder, position: Int) {
        holder.apply {
            txtName.text = usuarios[position].userName
            txtMail.text = usuarios[position].mail
            txtContraseña.text = usuarios[position].contraseña
            itemView.setOnClickListener {
                listener.onUsuariosClicked(usuarios[position])
            }
        }
    }

    override fun getItemCount() = usuarios.size
    fun updateUsuarios(usuarios: List<Usuario>) {
        this.usuarios = usuarios
        notifyDataSetChanged()
    }

    interface UsuariosListener {
        fun onUsuariosClicked(usuario: Usuario)
    }
}
