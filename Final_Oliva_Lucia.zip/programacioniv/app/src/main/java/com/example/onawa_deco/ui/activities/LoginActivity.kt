package com.example.onawa_deco.ui.activities

import android.content.Intent
import android.os.Bundle
import android.os.StrictMode
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.onawa_deco.R
import com.example.onawa_deco.data.Usuario
import com.example.onawa_deco.db.UsuariosDao
import com.example.onawa_deco.extensions.getTextFrom
import com.example.onawa_deco.extensions.mostrarMensaje
import io.reactivex.SingleObserver
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable

class LoginActivity : AppCompatActivity() {
    private lateinit var btnRegistrarse: Button
    private lateinit var btnIngresar: Button
    private lateinit var etMail: EditText
    private lateinit var etpassword: EditText
    private val compositeDisposable = CompositeDisposable()
    private var context = this@LoginActivity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        initStrictMode()
        setUpUI()
    }


    private fun initStrictMode() {
        StrictMode.setThreadPolicy(
            StrictMode.ThreadPolicy.Builder()
                .detectDiskReads()
                .detectDiskWrites()
                .detectNetwork()
                .penaltyLog()
                .build()
        )
        StrictMode.setVmPolicy(
            StrictMode.VmPolicy.Builder()
                .detectLeakedSqlLiteObjects()
                .detectLeakedClosableObjects()
                .penaltyLog()
                .penaltyDeath()
                .build()
        )
    }


    private fun setUpUI() {
        btnRegistrarse = findViewById(R.id.btRegristrarse)
        btnIngresar = findViewById(R.id.btIngresar)
        etMail = findViewById(R.id.etMail)
        etpassword = findViewById(R.id.etPassword)
        btnRegistrarse.setOnClickListener { cargarActivity(AgregarUsuarioActivity()) }
        btnIngresar.setOnClickListener { validacionIngreso() }
    }

    private fun validacionIngreso() {
        val mail = getTextFrom(etMail)
        val pass = getTextFrom(etpassword)

        if (mail.isNullOrEmpty() || pass.isNullOrEmpty()) {
            mostrarMensaje(getString(R.string.CamposIncompletos), context)

        } else {
            UsuariosDao(context.applicationContext).getUsuario(mail, pass)
                .subscribe(object : SingleObserver<Usuario> {
                    override fun onSubscribe(d: Disposable) {
                        compositeDisposable.add(d)
                    }

                    override fun onSuccess(usuarios: Usuario) {
                        cargarActivity(MainActivity())
                        finish()
                    }

                    override fun onError(e: Throwable) {
                        mostrarMensaje(getString(R.string.Registrarse), context)
                    }
                })
        }
    }

    private fun cargarActivity(activity: AppCompatActivity) {
        val intent = Intent(this, activity::class.java)
        startActivity(intent)
    }

}