package com.example.onawa_deco.network

import com.example.onawa_deco.data.NovedadResponse
import retrofit2.Call
import retrofit2.http.GET

interface NovedadesApi {
    @GET("/Novedades")
    fun getNovedades(): Call<List<NovedadResponse>>
}