package com.example.onawa_deco.model

import com.example.onawa_deco.data.Usuario

interface AgregarUsuarioRepository {

    fun agregarUsuario(usuario: Usuario, success: () -> Unit, error: () -> Unit)
}