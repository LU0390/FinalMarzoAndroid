package com.example.onawa_deco.ui.activities

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.onawa_deco.R
import com.example.onawa_deco.data.Articulo
import com.example.onawa_deco.db.ArticulosDao
import com.example.onawa_deco.extensions.getTextFrom
import com.example.onawa_deco.extensions.mostrarMensaje
import com.google.android.material.textfield.TextInputEditText
import io.reactivex.CompletableObserver
import io.reactivex.SingleObserver
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable


class ArticuloActivity : AppCompatActivity() {
    private lateinit var imImagen: ImageView
    private lateinit var etName: TextInputEditText
    private lateinit var etPrice: TextInputEditText
    private lateinit var etDescription: TextInputEditText
    private lateinit var btnGuardar: Button
    private lateinit var articuloModificar: Articulo
    private var idarticulomod = 0
    private val compositeDisposable = CompositeDisposable()
    private val context = this@ArticuloActivity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_articulo)
        setupUI()
    }

    private fun setupUI() {
        imImagen = findViewById(R.id.imgArticulo)
        etName = findViewById(R.id.etName)
        etPrice = findViewById(R.id.etPrice)
        etDescription = findViewById(R.id.etDescription)
        btnGuardar = findViewById(R.id.btnSave)
        btnGuardar.setOnClickListener { guardarArticulo() }

        cargarArticulo()
    }

    private fun guardarArticulo() {
        validateData()
        if (isDataValid()) {
            actualizarArticulo()
            ArticulosDao(context.applicationContext)
                .updateArticulo(articuloModificar).subscribe(object : CompletableObserver {
                    override fun onSubscribe(d: Disposable) {
                        compositeDisposable.add(d)
                    }

                    override fun onComplete() {
                        mostrarMensaje(getString(R.string.ArtMod), context)
                        finish()
                    }

                    override fun onError(e: Throwable) {
                        mostrarMensaje(getString(R.string.ErrorArtMod), context)
                    }
                })
        }

    }

    private fun actualizarArticulo() {
        articuloModificar.name = getTextFrom(etName)
        articuloModificar.description = getTextFrom(etDescription)
        articuloModificar.price = getTextFrom(etPrice)
    }

    private fun isDataValid() =
        etName.error.isNullOrEmpty() && etPrice.error.isNullOrEmpty()


    private fun validateData() {
        validateName()
        validatePrice()
    }

    private fun validateName() {
        if (getTextFrom(etName).isEmpty()) {
            etName.error = getString(R.string.FillName)
        }
    }

    private fun validatePrice() {
        if (getTextFrom(etPrice).isEmpty()) {
            etPrice.error = getString(R.string.FillPrice)
        }
    }


    private fun cargarArticulo() {
        val bundle = intent.extras
        idarticulomod = bundle?.getInt(getString(R.string.Articulo)) ?: 0
        ArticulosDao(context.applicationContext)
            .getArticulo(idarticulomod)
            .subscribe(object : SingleObserver<Articulo> {
                override fun onSubscribe(d: Disposable) {
                    compositeDisposable.add(d)
                }

                override fun onError(e: Throwable) {
                    mostrarMensaje(getString(R.string.ErrorCargarUsuarios), context)
                }

                override fun onSuccess(articulo: Articulo) {
                    articuloModificar = articulo
                    etName.setText(articulo.name)
                    etPrice.setText(articulo.price)
                    etDescription.setText(articulo.description)
                }
            })


    }

}


