package com.example.onawa_deco.ui.activities

import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.CheckBox
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.preference.PreferenceManager
import com.example.onawa_deco.R
import com.example.onawa_deco.notificaciones.ArticulosNotiChannelManager
import com.example.onawa_deco.preferences.PreferencesActivity
import io.reactivex.Single
import io.reactivex.SingleObserver
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

class CatalogoActivity : AppCompatActivity() {
    private lateinit var toolbar: Toolbar
    private lateinit var cbAgregar1: CheckBox
    private lateinit var cbAgregar2: CheckBox
    private lateinit var cbAgregar3: CheckBox
    private lateinit var cbAgregar4: CheckBox
    private lateinit var btnComprar: Button
    private var errorMail = 0
    private var mailUsuario: String? = " "
    private val compositeDisposable = CompositeDisposable()
    private val preferences: SharedPreferences by lazy {
        PreferenceManager.getDefaultSharedPreferences(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_catalogo)

        setUpUI()
    }

    private fun setUpUI() {
        validacionPreferenciasMail()
        setupToolbar()
        cbAgregar1 = findViewById(R.id.cbAgregar1)
        cbAgregar2 = findViewById(R.id.cbAgregar2)
        cbAgregar3 = findViewById(R.id.cbAgregar3)
        cbAgregar4 = findViewById(R.id.cbAgregar4)
        btnComprar = findViewById(R.id.btComprar)
        cbAgregar1.setOnClickListener { mostrarPopUpAgregado(cbAgregar1) }
        cbAgregar2.setOnClickListener { mostrarPopUpAgregado(cbAgregar2) }
        cbAgregar3.setOnClickListener { mostrarPopUpAgregado(cbAgregar3) }
        cbAgregar4.setOnClickListener { mostrarPopUpAgregado(cbAgregar4) }
        btnComprar.setOnClickListener { comprar() }

    }


    private fun validacionPreferenciasMail() {
        Single.fromCallable { preferences.getBoolean(getString(R.string.PrefMail), false) }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(object : SingleObserver<Boolean> {
                override fun onSubscribe(d: Disposable) {
                    compositeDisposable.add(d)
                }

                override fun onSuccess(t: Boolean) {
                    if (t) {
                        preferenciaMail()
                        errorMail = 0
                    } else
                        errorMail = 1
                }

                override fun onError(e: Throwable) {
                    errorMail = 1
                }

            })
    }

    private fun preferenciaMail() {
        mailUsuario =
            preferences.getString(getString(R.string.edPrefMail), getString(R.string.mailBlanco))
        if (mailUsuario.isNullOrEmpty()) {
            errorMail = 1
        } else
            errorMail = 0
    }


    private fun comprar() {
        validacionPreferenciasMail()
        if (errorMail == 1) {
            mostrarPopUpConfigurarMail()
        } else {
            mostrarPopUpCompraRealizada()
            enviarNotificacionCompra()
        }

    }

    private fun mostrarPopUpConfigurarMail() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(getString(R.string.ErrorMail))
            .setMessage(getString(R.string.MensajeCargueMail))
            .setNegativeButton(getString(R.string.IngresePref), { _, _ ->
                cargarActivity(PreferencesActivity(), 0)

            })
            .show()
    }

    private fun enviarNotificacionCompra() {
        ArticulosNotiChannelManager.createNotiChanelForNotification(this)
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, 0)

        NotificationCompat.Builder(
            this, ArticulosNotiChannelManager.NEW_ARTICULOS_CHANNEL_ID
        ).setSmallIcon(R.mipmap.iconoonawanegro)
            .setContentTitle(getString(R.string.HolaHicisteUnPedido))
            .setContentText("Te llegara un mail a $mailUsuario para finalizar la compra")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()
            .also { notification ->
                NotificationManagerCompat.from(this)
                    .notify(1, notification)
            }
    }

    private fun mostrarPopUpCompraRealizada() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(getString(R.string.Gracias))
            .setMessage(getString(R.string.LlegaraNotif))
            .setNegativeButton(getString(R.string.PaginaPrincipal2), { _, _ ->
                cargarActivity(MainActivity(), 1)

            })
            .show()
    }


    private fun mostrarPopUpAgregado(checkBox: CheckBox) {
        if (checkBox.isChecked) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle(getString(R.string.ProductoAgregado))
                .setMessage(getString(R.string.TocarBotonCompra))
                .setPositiveButton(getString(R.string.ok), { _, _ -> })
                .setNegativeButton(getString(R.string.Cancel), { _, _ ->
                    checkBox.isChecked = false
                })
                .show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.itemPreferencias -> cargarActivity(PreferencesActivity(), 0)
            R.id.itemLogOut -> finishAffinity()
        }

        return super.onOptionsItemSelected(item)
    }


    private fun cargarActivity(activity: AppCompatActivity, flagPrincipal: Int) {
        val intent = Intent(this, activity::class.java)
        if (flagPrincipal == 1) {
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
    }

    private fun setupToolbar() {
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = getString(R.string.Onawa)
    }

}