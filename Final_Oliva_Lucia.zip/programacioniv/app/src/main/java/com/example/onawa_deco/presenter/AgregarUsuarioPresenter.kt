package com.example.onawa_deco.presenter

import com.example.onawa_deco.data.Usuario

interface AgregarUsuarioPresenter {

    fun doAgregarUsuario(usuario: Usuario)
}