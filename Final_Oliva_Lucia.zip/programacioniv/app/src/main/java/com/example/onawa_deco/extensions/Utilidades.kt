package com.example.onawa_deco.extensions

import android.content.Context
import android.util.Patterns
import android.view.Menu
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.core.view.MenuItemCompat
import com.example.onawa_deco.R
import java.util.regex.Pattern


fun mostrarMensaje(mensaje: String, context: Context) {
        Toast.makeText(context, mensaje, Toast.LENGTH_LONG).show()
    }

fun createMenu(menu: Menu): Boolean {
    val item = menu.findItem(R.id.action_search)
    val searchView =
        MenuItemCompat.getActionView(item) as SearchView
    searchView?.setOnQueryTextListener(object :
        SearchView.OnQueryTextListener {
        override fun onQueryTextSubmit(query: String): Boolean {
            return false
        }

        override fun onQueryTextChange(newText: String): Boolean {
            return true
        }
    })
   return true
}

 fun getTextFrom(editText: EditText) = editText.text.toString()

fun validarMailValido(mail: String):Boolean {
    val pattern: Pattern = Patterns.EMAIL_ADDRESS
    return pattern.matcher(mail).matches()
}
