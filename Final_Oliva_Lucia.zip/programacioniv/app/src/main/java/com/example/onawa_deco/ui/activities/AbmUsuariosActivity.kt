package com.example.onawa_deco.ui.activities

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.RecyclerView
import com.example.onawa_deco.R
import com.example.onawa_deco.data.Usuario
import com.example.onawa_deco.db.UsuariosDao
import com.example.onawa_deco.extensions.createMenu
import com.example.onawa_deco.extensions.mostrarMensaje
import com.example.onawa_deco.preferences.PreferencesActivity
import com.example.onawa_deco.ui.adapter.UsuariosAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import io.reactivex.CompletableObserver
import io.reactivex.SingleObserver
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable

class AbmUsuariosActivity : AppCompatActivity(), UsuariosAdapter.UsuariosListener,
    NavigationView.OnNavigationItemSelectedListener {
    private lateinit var rvUsuarios: RecyclerView
    private lateinit var fabAdd: FloatingActionButton
    private var mDrawerLayout: DrawerLayout? = null
    private var mDrawerToggle: ActionBarDrawerToggle? = null
    private var navigationView: NavigationView? = null
    private val compositeDisposable = CompositeDisposable()
    private val adapter: UsuariosAdapter by lazy { UsuariosAdapter(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_abm_usuarios)
        setUpUI()
        retrieveUsuarios()
    }

    override fun onResume() {
        super.onResume()
        retrieveUsuarios()
    }


    private fun setUpUI() {
        val toolbar =
            findViewById<Toolbar>(R.id.toolBar)
        setSupportActionBar(toolbar)
        mDrawerLayout = findViewById(R.id.drawerLayout)
        mDrawerToggle =
            ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.open, R.string.close)
        mDrawerLayout!!.addDrawerListener(mDrawerToggle!!)
        mDrawerToggle!!.syncState()
        navigationView = findViewById(R.id.nav_view)
        navigationView!!.setNavigationItemSelectedListener(this)
        fabAdd = findViewById(R.id.fabAgregar)
        fabAdd.setOnClickListener { cargarActivity(AgregarUsuarioActivity(), 0) }
        rvUsuarios = findViewById(R.id.rvUsuarios)
        rvUsuarios.adapter = adapter
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.home -> {
                cargarActivity(MainActivity(), 1)
            }
            R.id.itemAboutMe -> {
                cargarActivity(AboutMeActivity(), 0)
            }
            R.id.itemAbmArticulos -> {
                cargarActivity(AbmArticulosActivity(), 1)
            }
            R.id.itemUsuarios -> {
                mostrarMensaje(getString(R.string.SeccionAbmUsuario), this)
            }
            R.id.contacto -> {
                mostrarMensaje(getString(R.string.TrabajandoEnFuncionalidad), this)
            }

        }
        mDrawerLayout!!.closeDrawer(GravityCompat.START)
        return false
    }

    private fun cargarActivity(activity: AppCompatActivity, flagPrincipal: Int) {
        val intent = Intent(this, activity::class.java)
        if (flagPrincipal == 1) {
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
    }


    override fun onBackPressed() {
        if (mDrawerLayout!!.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout!!.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return createMenu(menu)
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.itemPreferencias -> cargarActivity(PreferencesActivity(), 0)
            R.id.itemLogOut -> finishAffinity()
        }

        return super.onOptionsItemSelected(item)
    }


    override fun onUsuariosClicked(usuario: Usuario) {
        val builder = AlertDialog.Builder(this)
        builder
            .setTitle(getString(R.string.Usuario) + usuario.userName)
            .setMessage(getString(R.string.SeleccioneOpcion))
            .setPositiveButton(getString(R.string.Modificar), { _, _ ->
                mostrarMensaje(getString(R.string.TrabajandoEnLaSeccion), this)
            })
            .setNegativeButton(getString(R.string.Eliminar), { _, _ ->
                eliminarUsuario(usuario)

            })
            .show()

    }

    private fun retrieveUsuarios() {
        UsuariosDao(this@AbmUsuariosActivity.applicationContext).getUsuario()
            .subscribe(object : SingleObserver<List<Usuario>> {
                override fun onSubscribe(d: Disposable) {
                    compositeDisposable.add(d)
                }

                override fun onSuccess(usuarios: List<Usuario>) {
                    adapter.updateUsuarios(usuarios)
                }

                override fun onError(e: Throwable) {
                    mostrarMensaje(
                        getString(R.string.ErrorCargarUsuarios),
                        this@AbmUsuariosActivity
                    )
                }
            })
    }

    private fun eliminarUsuario(usuario: Usuario) {
        val builder = AlertDialog.Builder(this)
        builder
            .setTitle(getString(R.string.EliminarUsuario))
            .setMessage(getString(R.string.EliminarUsuarioPreg) + usuario.userName + getString(R.string.SignoPregunta))
            .setPositiveButton(getString(R.string.ok)) { _, _ ->
                UsuariosDao(this@AbmUsuariosActivity.applicationContext)
                    .deleteUsuario(usuario)
                    .subscribe(object : CompletableObserver {
                        override fun onSubscribe(d: Disposable) {
                            compositeDisposable.add(d)
                        }

                        override fun onComplete() {
                            retrieveUsuarios()
                            mostrarMensaje(
                                getString(R.string.UsuarioEliminado),
                                this@AbmUsuariosActivity
                            )
                        }

                        override fun onError(e: Throwable) {
                            mostrarMensaje(
                                getString(R.string.ErrorEliminarUsuario),
                                this@AbmUsuariosActivity
                            )
                        }
                    })
            }

            .setNegativeButton(getString(R.string.Cancel)) { _, _ ->
            }
            .show()
    }

    override fun onStop() {
        super.onStop()
        compositeDisposable.clear()
    }

}