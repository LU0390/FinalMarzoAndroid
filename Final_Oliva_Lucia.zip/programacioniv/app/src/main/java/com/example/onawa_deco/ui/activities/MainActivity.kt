package com.example.onawa_deco.ui.activities


import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.preference.PreferenceManager
import com.example.onawa_deco.data.NovedadResponse
import com.example.onawa_deco.preferences.PreferencesActivity
import com.example.onawa_deco.R
import com.example.onawa_deco.extensions.createMenu
import com.example.onawa_deco.extensions.mostrarMensaje
import com.example.onawa_deco.network.NovedadesNetworkIClient
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.material.navigation.NavigationView
import com.google.firebase.messaging.FirebaseMessaging
import io.reactivex.Single
import io.reactivex.SingleObserver
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


var URL = " "

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    private var mDrawerLayout: DrawerLayout? = null
    private var mDrawerToggle: ActionBarDrawerToggle? = null
    private var navigationView: NavigationView? = null
    private lateinit var btnCatalogo: Button
    private lateinit var btnOhMychalk: ImageButton
    private lateinit var btnCarrusel1: ImageButton
    private lateinit var btnCarrusel2: ImageButton
    private lateinit var tvNovedad1: TextView
    private lateinit var tvNovedad2: TextView
    private lateinit var tvNovedad3: TextView
    private val compositeDisposable = CompositeDisposable()


    private val preferences: SharedPreferences by lazy {
        PreferenceManager.getDefaultSharedPreferences(this)
    }


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setUI()
        cargaNovedades()
        printFirebaseToken()

    }


    private fun setUI() {
        val toolbar =
            findViewById<Toolbar>(R.id.toolBar)
        setSupportActionBar(toolbar)
        mDrawerLayout = findViewById(R.id.drawerLayout)
        mDrawerToggle =
            ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.open, R.string.close)
        mDrawerLayout!!.addDrawerListener(mDrawerToggle!!)
        mDrawerToggle!!.syncState()
        navigationView = findViewById(R.id.nav_view)
        navigationView!!.setNavigationItemSelectedListener(this)
        btnCarrusel1 = findViewById(R.id.fotoCarrusel1)
        btnCarrusel2 = findViewById(R.id.fotoCarrusel3)
        btnOhMychalk = findViewById(R.id.ibOhMyChalk)
        btnCatalogo = findViewById(R.id.btCatalogo)
        btnOhMychalk.setOnClickListener { cargarWeb() }
        btnCatalogo.setOnClickListener { cargarActivity(CatalogoActivity()) }
        btnCarrusel1.setOnClickListener { cargarActivity(CatalogoActivity()) }
        btnCarrusel2.setOnClickListener { cargarActivity(CatalogoActivity()) }
        tvNovedad1 = findViewById(R.id.tvNovedad1)
        tvNovedad2 = findViewById(R.id.tvNovedad2)
        tvNovedad3 = findViewById(R.id.tvNovedad3)

        preferenciaSaludo()

    }

    private fun cargarWeb() {
        URL = getString(R.string.PaginaOhMyChalk)
        cargarActivity(PaginasWebActivity())
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.home -> {
                mostrarMensaje(getString(R.string.PaginaPrincipal), this)
            }
            R.id.itemAboutMe -> {
                cargarActivity(AboutMeActivity())
            }
            R.id.itemAbmArticulos -> {
                cargarActivity(AbmArticulosActivity())
            }
            R.id.itemUsuarios -> {
                cargarActivity(AbmUsuariosActivity())
            }
            R.id.contacto -> {
                mostrarMensaje(getString(R.string.TrabajandoEnLaSeccion), this)
            }

        }
        mDrawerLayout!!.closeDrawer(GravityCompat.START)
        return false
    }

    private fun cargarActivity(activity: AppCompatActivity) {
        val intent = Intent(this, activity::class.java)
        startActivity(intent)
    }


    override fun onBackPressed() {
        if (mDrawerLayout!!.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout!!.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return createMenu(menu)
    }

    private fun printFirebaseToken() {
        val TAG = getString(R.string.TokenOnawa)
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                return@OnCompleteListener
            }
            val token = task.result
            Log.d(TAG, token.orEmpty())
        })
    }

    private fun cargaNovedades() {

        NovedadesNetworkIClient.NovedadesApi.getNovedades().enqueue(object :
            Callback<List<NovedadResponse>> {

            override fun onResponse(
                call: Call<List<NovedadResponse>>,
                response: Response<List<NovedadResponse>>
            ) {
                response.body()
                tvNovedad1.text = response.body()?.get(0)?.description.toString()
                tvNovedad2.text = response.body()?.get(1)?.description.toString()
                tvNovedad3.text = response.body()?.get(2)?.description.toString()
            }

            override fun onFailure(call: Call<List<NovedadResponse>>, t: Throwable) {
                mostrarMensaje(getString(R.string.ErrorCargaNovedades), this@MainActivity)
            }
        })
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.itemPreferencias -> cargarActivity(PreferencesActivity())
            R.id.itemLogOut -> finishAffinity()
        }

        return super.onOptionsItemSelected(item)
    }


    private fun preferenciaSaludo() {
        validacionPreferenciasNombre()
    }


    private fun validacionPreferenciasNombre() {
        Single.fromCallable { preferences.getBoolean(getString(R.string.NombrePref), false) }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(object : SingleObserver<Boolean> {
                override fun onSubscribe(d: Disposable) {
                    compositeDisposable.add(d)
                }

                override fun onSuccess(t: Boolean) {
                    if (t)
                        armarSaludo()
                }

                override fun onError(e: Throwable) {
                    mostrarMensaje(getString(R.string.ErrorCargaPref), this@MainActivity)
                }

            })
    }

    private fun armarSaludo() {
        var nombreUsuario = preferences.getString(getString(R.string.NombPref), getString(R.string.FaltaNombre))
        val builder = AlertDialog.Builder(this)
        if (nombreUsuario.isNullOrBlank()) {
            builder.setTitle(getString(R.string.Hola))
                .setMessage(getString(R.string.GraciasUsuario))
                .setPositiveButton(getString(R.string.Cerrar), { _, _ -> })
                .show()
        } else {
            builder.setTitle(getString(R.string.Hola))
                .setMessage("Muchas gracias $nombreUsuario  por estar usando nuestra aplicacion :)")
                .setPositiveButton(getString(R.string.Cerrar), { _, _ -> })
                .show()
        }

    }


}


