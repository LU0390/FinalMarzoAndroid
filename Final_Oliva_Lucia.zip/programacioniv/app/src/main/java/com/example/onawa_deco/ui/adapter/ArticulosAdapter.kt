package com.example.onawa_deco.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.onawa_deco.R
import com.example.onawa_deco.data.Articulo

class ArticulosAdapter(val listener: ArticulosListener) :
    RecyclerView.Adapter<ArticulosAdapter.ArticulosViewHolder>() {


    class ArticulosViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgArticulo = itemView.findViewById<ImageView>(R.id.imgImagenArticulo)
        val txtName: TextView = itemView.findViewById(R.id.txtNombreArt)
        val txtPrice: TextView = itemView.findViewById(R.id.txtPrecio)
    }

    private var articulos: List<Articulo> = emptyList()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArticulosViewHolder {
        val itemView = LayoutInflater
            .from(parent.context)
            .inflate(
                R.layout.item_articulo,
                parent,
                false
            )

        return ArticulosViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ArticulosViewHolder, position: Int) {
        holder.apply {
            imgArticulo.setImageResource(articulos[position].resImage)
            txtName.text = articulos[position].name
            txtPrice.text = articulos[position].price
            itemView.setOnClickListener {
                listener.onArticulosClicked(articulos[position])
            }
        }
    }

    override fun getItemCount() = articulos.size
    fun updateArticulos(articulos: List<Articulo>) {
        this.articulos = articulos
        notifyDataSetChanged()
    }

    interface ArticulosListener {
        fun onArticulosClicked(articulo: Articulo)
    }
}
