package com.example.onawa_deco.data

import android.os.Parcelable
import com.j256.ormlite.field.DatabaseField
import com.j256.ormlite.table.DatabaseTable
import kotlinx.android.parcel.Parcelize

@DatabaseTable(tableName = "Usuarios")
@Parcelize
class Usuario(
    @DatabaseField
    var userName: String,
    @DatabaseField(id = true)
    var mail: String,
    @DatabaseField
    var contraseña: String,

    ) : Parcelable {

    constructor() : this("", "", "")
}
