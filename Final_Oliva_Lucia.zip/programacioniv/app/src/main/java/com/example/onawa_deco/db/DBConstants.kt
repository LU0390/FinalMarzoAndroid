package com.example.onawa_deco.db

const val DB_NAME = "Onawa_Deco"
const val DB_VERSION = 2