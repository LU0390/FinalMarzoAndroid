package com.example.onawa_deco.ui.activities

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.RecyclerView
import com.example.onawa_deco.*
import com.example.onawa_deco.db.ArticulosDao
import com.example.onawa_deco.data.Articulo
import com.example.onawa_deco.preferences.PreferencesActivity
import com.example.onawa_deco.extensions.createMenu
import com.example.onawa_deco.extensions.mostrarMensaje
import com.example.onawa_deco.ui.adapter.ArticulosAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import io.reactivex.CompletableObserver
import io.reactivex.SingleObserver
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable


class AbmArticulosActivity : AppCompatActivity(), ArticulosAdapter.ArticulosListener,
    NavigationView.OnNavigationItemSelectedListener {
    private var mDrawerLayout: DrawerLayout? = null
    private var mDrawerToggle: ActionBarDrawerToggle? = null
    private var navigationView: NavigationView? = null
    private lateinit var rvArticulos: RecyclerView
    private lateinit var fabAdd: FloatingActionButton
    private val adapter: ArticulosAdapter by lazy { ArticulosAdapter(this) }
    private val compositeDisposable = CompositeDisposable()
    private val context = this@AbmArticulosActivity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_abm_articulos)
        setUpUI()

    }

    override fun onResume() {
        super.onResume()
        retrieveArticulos()
    }

    private fun retrieveArticulos() {

        ArticulosDao(context.applicationContext).getArticulos()
            .subscribe(object : SingleObserver<List<Articulo>> {
                override fun onSubscribe(d: Disposable) {
                    compositeDisposable.add(d)
                }

                override fun onError(e: Throwable) {
                    mostrarMensaje(getString(R.string.ErrorCargarUsuarios), context)
                }

                override fun onSuccess(articulos: List<Articulo>) {
                    adapter.updateArticulos(articulos)
                }
            })
    }

    private fun setUpUI() {
        val toolbar =
            findViewById<Toolbar>(R.id.toolBar)
        setSupportActionBar(toolbar)
        mDrawerLayout = findViewById(R.id.drawerLayout)
        mDrawerToggle =
            ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.open, R.string.close)
        mDrawerLayout!!.addDrawerListener(mDrawerToggle!!)
        mDrawerToggle!!.syncState()
        navigationView = findViewById(R.id.nav_view)
        navigationView!!.setNavigationItemSelectedListener(this)
        fabAdd = findViewById(R.id.fabAgregar)
        fabAdd.setOnClickListener { cargarActivity(AgregarArticuloActivity(), 0) }
        rvArticulos = findViewById(R.id.rvArticulos)
        rvArticulos.adapter = adapter
    }


    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.home -> {
                cargarActivity(MainActivity(), 1)
            }
            R.id.itemAboutMe -> {
                cargarActivity(AboutMeActivity(), 0)
            }
            R.id.itemAbmArticulos -> {
                mostrarMensaje(getString(R.string.SeEncuentraABMArticulos), this)
            }
            R.id.itemUsuarios -> {
                cargarActivity(AbmUsuariosActivity(), 0)
            }
            R.id.contacto -> {
                mostrarMensaje(getString(R.string.TrabajandoEnLaSeccion), this)
            }
        }
        mDrawerLayout!!.closeDrawer(GravityCompat.START)
        return false
    }


    private fun cargarActivity(activity: AppCompatActivity, flagPrincipal: Int) {
        val intent = Intent(this, activity::class.java)
        if (flagPrincipal == 1) {
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
    }

    override fun onBackPressed() {
        if (mDrawerLayout!!.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout!!.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return createMenu(menu)
    }


    override fun onArticulosClicked(articulo: Articulo) {
        val builder = AlertDialog.Builder(this)
        builder
            .setTitle(articulo.name)
            .setMessage(getString(R.string.SeleccioneOpcion))
            .setPositiveButton(getString(R.string.Modificar), { _, _ ->
                modificarOVerDetArticulo(articulo, ArticuloActivity())
            })
            .setNeutralButton(getString(R.string.Detalle), { _, _ ->
                modificarOVerDetArticulo(articulo, DetalleArticuloActivity())
            })
            .setNegativeButton(getString(R.string.Eliminar), { _, _ ->
                eliminarArticulo(articulo)
            })
            .show()

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.itemPreferencias -> cargarActivity(PreferencesActivity(), 0)
            R.id.itemLogOut -> finishAffinity()
        }

        return super.onOptionsItemSelected(item)
    }

    private fun modificarOVerDetArticulo(articulo: Articulo, activity: AppCompatActivity) {
        val intent = Intent(this, activity::class.java)
        intent.putExtra(getString(R.string.Articulo), articulo.id)
        startActivity(intent)
    }

    private fun eliminarArticulo(articulo: Articulo) {
        val builder = AlertDialog.Builder(this)
        builder
            .setTitle(getString(R.string.EliminarArt))
            .setMessage(getString(R.string.QuiereEliminarArt) + articulo.name + getString(R.string.SignoPregunta))
            .setPositiveButton(getString(R.string.ok)) { _, _ ->
                ArticulosDao(context.applicationContext)
                    .deleteArticulo(articulo)
                    .subscribe(object : CompletableObserver {
                        override fun onSubscribe(d: Disposable) {
                            compositeDisposable.add(d)
                        }

                        override fun onComplete() {
                            retrieveArticulos()
                            mostrarMensaje(getString(R.string.ArtEliminado), context)
                        }

                        override fun onError(e: Throwable) {
                            mostrarMensaje(getString(R.string.ErrorEliminarArt), context)
                        }
                    })
            }

            .setNegativeButton(getString(R.string.Cancel)) { _, _ ->
            }
            .show()
    }


}